<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brand extends MY_Controller {


public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('storemanager/store_brand_model');

 if(!isset($_SESSION['owner_id'])){
            header( "location: ".$this->base_url."/storemanager/login" );
        }

    }


	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
         $this->load->helper('url');
		$data['tab'] = 'brand';
		$data['title'] = 'Store Manager Brand';
		$this->deshboardlayout('storemanager/brand',$data);
	}


  

	function Add()
    {

$data = json_decode(file_get_contents("php://input"),true);
if(!isset($data)){
exit();
}

$success = $this->store_brand_model->Add($data);

}





	function Addbranch()
    {

$data = json_decode(file_get_contents("php://input"),true);
if(!isset($data)){
exit();
}

$success = $this->store_brand_model->Addbranch($data);

}



	function Editebranch()
    {

$data = json_decode(file_get_contents("php://input"),true);
if(!isset($data)){
exit();
}

$success = $this->store_brand_model->Editebranch($data);

}





	function Getbranch()
    {

echo $this->store_brand_model->Getbranch();

}





	function Logoonslip()
    {

$data = json_decode(file_get_contents("php://input"),true);
if(!isset($data)){
exit();
}

$success = $this->store_brand_model->Logoonslip($data);

}






	function Fontc2m()
    {

$data = json_decode(file_get_contents("php://input"),true);
if(!isset($data)){
exit();
}

$success = $this->store_brand_model->Fontc2m($data);

}



	function Fontslip()
    {

$data = json_decode(file_get_contents("php://input"),true);
if(!isset($data)){
exit();
}

$success = $this->store_brand_model->Fontslip($data);

}










	function Addimg()
    {

if(isset($_FILES["owner_logo"]["name"]) && $_FILES["owner_logo"]["name"] != ''){

if(!file_exists("pic/logo/".$_SESSION['store_id'])){
	mkdir("pic/logo/".$_SESSION['store_id'],0777,true);
}

    $upload = move_uploaded_file($_FILES["owner_logo"]["tmp_name"],"pic/logo/".$_SESSION['store_id']."/".time().md5($_FILES["owner_logo"]["name"]).'.jpg');

    $data['owner_logo'] = 'pic/logo/'.$_SESSION['store_id'].'/'.time().md5($_FILES["owner_logo"]["name"]).'.jpg';

}else{
$data['owner_logo'] = '';
}


$data['owner_id'] = $_POST['owner_id'];


$success = $this->store_brand_model->Addimg($data);

}

// add new for owner QR -----------------
// 	function Addqr()
//     {

// if(isset($_FILES["owner_qr"]["name"]) && $_FILES["owner_qr"]["name"] != ''){

// if(!file_exists("pic/owner_qr/".$_SESSION['store_id'])){
// 	mkdir("pic/owner_qr/".$_SESSION['store_id'],0777,true);
// }

//     $upload = move_uploaded_file($_FILES["owner_qr"]["tmp_name"],"pic/owner_qr/".$_SESSION['store_id']."/".time().md5($_FILES["owner_qr"]["name"]).'.jpg');

//     $data['owner_qr'] = 'pic/owner_qr/'.$_SESSION['store_id'].'/'.time().md5($_FILES["owner_qr"]["name"]).'.jpg';

// }else{
// $data['owner_qr'] = '';
// }


// $data['owner_id'] = $_POST['owner_id'];


// $success = $this->store_brand_model->Addimg($data);

// }

function Addqr()
{
    $data = array();
    
    $owner_id = isset($_POST['owner_id']) ? $_POST['owner_id'] : 0;
    $data['owner_id'] = $owner_id;

    if(isset($_FILES["owner_qr"]["name"]) && $_FILES["owner_qr"]["name"] != '') {

        $dir = "pic/owner_qr/".$_SESSION['store_id'];
        if(!file_exists($dir)){
            mkdir($dir, 0777, true);
        }

        $filename = $dir.'/'.time().md5($_FILES["owner_qr"]["name"]).'.jpg';

        if(move_uploaded_file($_FILES["owner_qr"]["tmp_name"], $filename)){
            $data['owner_qr'] = $filename;
        }
    }

    // Call model function to update only the fields present
    $success = $this->store_brand_model->Addimg($data);

    if($success){
        echo json_encode(['status' => 'success', 'path' => isset($data['owner_qr']) ? $data['owner_qr'] : '']);
    } else {
        echo json_encode(['status' => 'error']);
    }
}


// add new for QR code EMVCo string -----------------

// Option B: Uploads the image AND automatically extracts/saves the EMVCo string
 public function Addqr_with_emvco()
{
    $owner_id = isset($_POST['owner_id']) ? $_POST['owner_id'] : 0;
    $data = array('owner_id' => $owner_id);

    $image_path = $this->_handle_qr_upload();
    if ($image_path) {
        $data['owner_qr'] = $image_path;

        // Automatically extract raw EMVCo string from the uploaded file
        $emvco_string = $this->_extract_emvco_string($image_path);
        if (!empty($emvco_string)) {
            $data['owner_emvco_string'] = $emvco_string;
        }
    }

    // Updates both owner_qr and owner_emvco_string in one go
    $success = $this->store_brand_model->Addimg($data);

    if ($success) {
        echo json_encode([
            'status' => 'success', 
            'path' => isset($data['owner_qr']) ? $data['owner_qr'] : '',
            'emvco_string' => isset($data['owner_emvco_string']) ? $data['owner_emvco_string'] : ''
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to save data']);
    }
}

private function _handle_qr_upload()
{
    if (isset($_FILES["owner_qr"]["name"]) && $_FILES["owner_qr"]["name"] != '') {
        $dir = "pic/owner_qr/".$_SESSION['store_id'];
        
        if (!file_exists($dir)) {
            mkdir($dir, 0777, true);
        }

        $filename = $dir.'/'.time().md5($_FILES["owner_qr"]["name"]).'.jpg';

        if (move_uploaded_file($_FILES["owner_qr"]["tmp_name"], $filename)) {
            return $filename;
        }
    }
    return false;
}

private function _extract_emvco_string($filename)
{
    require_once FCPATH . 'vendor/autoload.php';

    try {
        $absolute_path = FCPATH . $filename;
        
        if (!file_exists($absolute_path)) {
            return '';
        }

        if (class_exists('Zxing\QrReader')) {
            $qrcode = new \Zxing\QrReader($absolute_path);
        } elseif (class_exists('QrReader')) {
            $qrcode = new QrReader($absolute_path);
        } else {
            return '';
        }

        $text = $qrcode->text();
        return !empty($text) ? trim($text) : '';
    } catch (Exception $e) {
        return '';
    }
}


// add new for QR code EMVCo string -----------------


function Addbgimg()
    {

if(isset($_FILES["owner_bgimg"]["name"]) && $_FILES["owner_bgimg"]["name"] != ''){

if(!file_exists("pic/bg/".$_SESSION['store_id'])){
	mkdir("pic/bg/".$_SESSION['store_id'],0777,true);
}

    $upload = move_uploaded_file($_FILES["owner_bgimg"]["tmp_name"],"pic/bg/".$_SESSION['store_id']."/".time().md5($_FILES["owner_bgimg"]["name"]).'.jpg');

    $data['owner_bgimg'] = 'pic/bg/'.$_SESSION['store_id'].'/'.time().md5($_FILES["owner_bgimg"]["name"]).'.jpg';

}else{
$data['owner_bgimg'] = '';
}


$data['owner_id'] = $_POST['owner_id'];


$success = $this->store_brand_model->Addbgimg($data);

}




	function Edit()
    {

$data = json_decode(file_get_contents("php://input"),true);
if(!isset($data)){
exit();
}

$success = $this->store_brand_model->Edit($data);

}



function Updatefooter_slip()
  {

$data = json_decode(file_get_contents("php://input"),true);
if(!isset($data)){
exit();
}

$success = $this->store_brand_model->Updatefooter_slip($data);

}



function Get()
    {

echo $this->store_brand_model->Get();

}



function Savecolortheme()
    {
$this->store_brand_model->Savecolortheme($_POST['color_theme']);
//echo $_POST['color_theme'];
header( "location: ".$_SERVER["HTTP_REFERER"]);
}






}